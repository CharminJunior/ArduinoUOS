ArduinoUOS Library Notes

เอกสารฉบับนี้เป็นสรุปฟังก์ชันและการใช้งานเบื้องต้น สำหรับผู้เริ่มต้นหรือผู้ที่ไม่คุ้นเคยกับไลบรารี ArduinoUOS สามารถคัดลอกไฟล์นี้ไปวางเป็น "README.txt" หรือเปิดอ่านในโฟลเดอร์ไลบรารีได้เลย

1. I/O Helpers
   1.1 "dRead(pin,mode)"
    - เซ็ตโหมดพิน (mode: 1=OUTPUT,2=INPUT,3=INPUT\_PULLUP) แล้วอ่านค่าสัญญาณดิจิทัล
   1.2 "btn(pin)"
    - อ่านปุ่มแบบ active-low (กดแล้วคืนค่า true)
   1.3 "ARead(ch)"
    - อ่านค่าแอนะล็อกจากช่อง ch (0–1023)
   1.4 "pwm(i,v)"
    - เขียน PWM ไปยังพินในตาราง pwmPins\[] ตามดัชนี i
   1.5 "outD(pin,v)"
    - เซ็ตพินเป็น OUTPUT แล้ว digitalWrite(v)
   1.6 "gml()"
    - คืนค่า millis() 
   1.7 "gmc()"
    - คืนค่า micros()

2. EEPROM Helpers
   2.1 "eWb(addr,val)"
    - เขียนไบต์ val ลง EEPROM ที่ addr
   2.2 "eRb(addr)"
    - อ่านไบต์จาก EEPROM ที่ addr
   2.3 "eWi(addr,val)"
    - เขียน int val ลง EEPROM 2 ไบต์
   2.4 "eRi(addr)"
    - อ่าน int จาก EEPROM 2 ไบต์
   2.5 "eWs(addr,str)"
    - เขียน String str ลง EEPROM (สูงสุด 255 ตัวอักษร)
   2.6 "eRs(addr)"
    - อ่าน String จาก EEPROM

3. Watchdog
   3.1 "wdOn()"
    - เปิดใช้งาน watchdog (1 วินาที)
   3.2 "wdR()"
    - รีเซ็ต watchdog

4. Pin-Mode Abstraction
   4.1 "pinCfg(pin,m)"
    - เซ็ตโหมดพิน (m: 1=OUTPUT,2=INPUT,3=INPUT\_PULLUP)

5. Serial I/O Helpers
   5.1 "sIn(prompt)"
    - แสดง prompt แล้วอ่านบรรทัดจาก Serial (return char\*)

6. List Management (สองลิสต์)
   * ลิสต์หลัก: เก็บข้อความในตัวแปร hsuorg
   * ลิสต์รอง: เก็บข้อความในตัวแปร sysItems
       6.1 "pClr()"
     * เคลียร์ลิสต์หลัก (reset index)
       6.2 "pAdd(txt)"
     * เพิ่มข้อความ txt ลงลิสต์หลัก
       6.3 "sClr()"
     * เคลียร์ลิสต์รอง
       6.4 "sAdd(txt)"
     * เพิ่มข้อความ txt ลงลิสต์รอง

7. My\_print Class (object: p)
   * ใช้พิมพ์ข้อความผ่าน Serial ง่ายๆ
       7.1 "p.b(b)"
     * เริ่ม Serial ด้วย baud rate b
       7.2 "p.text(x)"
     * พิมพ์ ข้อความลงไปใน x
       7.3 "p()"
     * คืน true ถ้า Serial พร้อมใช้งาน
