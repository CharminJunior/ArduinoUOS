#include "ArduinoUOS.h"

/* ----------------------------
   Global Variables (Definitions)
   ---------------------------- */
char hsuorg[MAX_LIST_ITEMS][MAX_ITEM_LEN];
char sysItems[MAX_LIST_ITEMS][MAX_ITEM_LEN];
int list_count = 0;
int list_count_2 = 0;

/* ----------------------------
   My_print Class Implementation
   ---------------------------- */
// นิยามตัวแปร global
My_print p;

// constructor
My_print::My_print() {
  // ไม่ต้องทำอะไรพิเศษ
}

// ฟังก์ชัน non‑template
void My_print::b(long baud) {
  Serial.begin(baud);
  while (!Serial) {}
  //Serial.print("\n");
}

/* ----------------------------
   I/O Helpers Implementation
   ---------------------------- */
bool DRead(int pin, int SetPin) {
  setPinMode(pin, SetPin);
  return digitalRead(pin);
}

bool btn(int pin) {
  return !(bool(DRead(pin, 3)));
}

int ARead(int ch) {
  return analogRead(ch);
}

void pwm(uint8_t idx, uint8_t value) {
  //const uint8_t pwmPins[] = { -1, 3, 5, 6, 9, 10, 11 };
  //if (idx < sizeof(pwmPins) / sizeof(pwmPins[0])) {
    //uint8_t pin = pwmPins[idx];
  uint8_t pin = idx;
  pinMode(pin, OUTPUT);
  analogWrite(pin, value);
  //}
}

void outD(int pin, bool value) {
  setPinMode(pin, 1);
  digitalWrite(pin, value ? HIGH : LOW);
}

unsigned long gml() {
  return millis();
}

unsigned long gmc() {
  return micros();
}

/* ----------------------------
   EEPROM Helpers Implementation
   ---------------------------- */
void writeByteToEEPROM(int address, byte value) {
  EEPROM.update(address, value);
}

byte readByteFromEEPROM(int address) {
  return EEPROM.read(address);
}

void writeIntToEEPROM(int address, int value) {
  byte lowByteValue  = lowByte(value);
  byte highByteValue = highByte(value);
  EEPROM.update(address,     lowByteValue);
  EEPROM.update(address + 1, highByteValue);
}

int readIntFromEEPROM(int address) {
  byte lowByteValue  = EEPROM.read(address);
  byte highByteValue = EEPROM.read(address + 1);
  return word(highByteValue, lowByteValue);
}

void writeStringToEEPROM(int address, const String &data) {
  int len = data.length();
  if (len > 255) len = 255;
  EEPROM.update(address, len);
  for (int i = 0; i < len; i++) {
    EEPROM.update(address + 1 + i, data[i]);
  }
}

String readStringFromEEPROM(int address) {
  byte len = EEPROM.read(address);
  char buf[256];
  for (int i = 0; i < len; i++) {
    buf[i] = EEPROM.read(address + 1 + i);
  }
  buf[len] = '\0';
  return String(buf);
}

/* ----------------------------
   Watchdog Implementation
   ---------------------------- */
void enableWatchdog() {
  wdt_enable(WDTO_1S);
}

void resetWatchdog() {
  wdt_reset();
}

/* ----------------------------
   Pin-Mode Abstraction Implementation
   ---------------------------- */
void setPinMode(uint8_t pin, uint8_t mode) {
  const uint8_t yio[] = { 0, OUTPUT, INPUT, INPUT_PULLUP };
  if (mode >= 1 && mode <= 3) {
    pinMode(pin, yio[mode]);
  }
}

/* ----------------------------
   Serial Input Helpers Implementation
   ---------------------------- */
// อ่านจนเจอ '\n' หรือจนบัฟเฟอร์เต็ม (เหลือ 1 byte 0-terminator)
char* input(const char* prompt) {
  // จองบัฟเฟอร์ภายในฟังก์ชัน (ปรับขนาดได้ตามต้องการ)
  static char buf[64];
  size_t idx = 0;
  p.text(prompt," >>> ");
  while (true) {
    if (Serial.available() > 0) {
      char c = Serial.read();
      if (c == '\r') continue;            // ข้าม CR
      if (c == '\n' || idx >= sizeof(buf)-1) break;
      buf[idx++] = c;
    }
  }
  buf[idx] = '\0';
  p.text(buf,"\n");
  return buf;
}

char* input() {
  // จองบัฟเฟอร์ภายในฟังก์ชัน (ปรับขนาดได้ตามต้องการ)
  static char buf[64];
  size_t idx = 0;
  while (true) {
    if (Serial.available() > 0) {
      char c = Serial.read();
      if (c == '\r') continue;            // ข้าม CR
      if (c == '\n' || idx >= sizeof(buf)-1) break;
      buf[idx++] = c;
    }
  }
  buf[idx] = '\0';
  return buf;
}

/* ----------------------------
   List Management Implementation
   ---------------------------- */
void outS() {
  list_count = 0;
}

void outL() {
  list_count_2 = 0;
}

void addS(const char* text) {
  if (list_count >= MAX_LIST_ITEMS) return;
  strncpy(hsuorg[list_count], text, MAX_ITEM_LEN - 1);
  hsuorg[list_count][MAX_ITEM_LEN - 1] = '\0';
  list_count++;
}

void addL(const char* text) {
  if (list_count_2 >= MAX_LIST_ITEMS) return;
  strncpy(sysItems[list_count_2], text, MAX_ITEM_LEN - 1);
  sysItems[list_count_2][MAX_ITEM_LEN - 1] = '\0';
  list_count_2++;
}
